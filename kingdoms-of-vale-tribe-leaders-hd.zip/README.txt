Kingdoms of Vale - 7 HD tribe leader portraits.
These are original high-resolution portrait assets. The website PR #11 contains a compact embedded portrait atlas for the selection UI.
